<style>
   body{
        background-color: goldenrod;
        
    }
    h2{
        color: palegreen;
    }

    .border {border-style: solid; margin:0 auto; text-align: left; height:400px; width: 400px}
    
</style>
<?php
    include "header.php";
    ?>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<div class="border">
    <h1>Checkout</h1>
    <script>
      document.writeln("<h3> Your total for the strawberries is: 5.70$ </h3> ");
      document.writeln("<h3> Your total for the ground cherries: 7.20$ </h3> ");
      document.writeln("<h3> Your total for the honeycrisp apples: 9.30$ </h3> ");
      document.writeln("<h2> Your total is : 22.00 $ </h2> ");

    </script>
    <br/>
    <br/>
    <br/>
    <form action="buyerHome.php">
        <input type="submit" value="Confirm Purchase">
    </form>
</div>

<br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>

 <?php
        include "footer.php";
        ?>